Flickrdemo

Application description:
The Flickr demo shows your current GPS location. It allows you to download and 
view photos from the Flickr website that are marked as being within a 5km radius 
of where you currently are. It demonstrates how to use Location and Bearer Management
from Mobility API.

Tested platforms:
- Qt for Symbian 4.6.
- S60 3rd Edition, FP1
- S60 5th Edition

Phones tested with:
- Nokia N95
- Nokia 5800 XpressMusic

