The data in fastfood.gpx was sourced from
http://www.gps-data-team.info/poi/australia/restaurants/McDonalds.php
